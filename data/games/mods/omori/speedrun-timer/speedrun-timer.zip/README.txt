Omori Speedrun Timer v1.0
Placeholder zip - substitua pelo arquivo real.
