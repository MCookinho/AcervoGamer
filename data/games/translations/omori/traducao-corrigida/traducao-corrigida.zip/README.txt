Omori Traducao Corrigida v2.0
Placeholder zip - substitua pelo arquivo real.
