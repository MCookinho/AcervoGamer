Deltarune Cap 2 Traducao v2.0
Placeholder zip - substitua pelo arquivo real.
