Deltarune Traducao PT-BR v1.0
Placeholder zip - substitua pelo arquivo real.
