Omori Traducao PT-BR v1.5
Placeholder zip - substitua pelo arquivo real.
