Deltarune Randomizer v1.2
Placeholder zip - substitua pelo arquivo real.
